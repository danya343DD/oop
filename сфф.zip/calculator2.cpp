#include "calculator2.h"
#include "ui_calculator2.h"
#include <QMessageBox>
#include <QPushButton>
#include <QList>

calculator2::calculator2(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::calculator2)
    , firstNumber(0)
    , secondNumber(0)
    , operation("")
    , userIsTypingSecondNumber(false)
{
    ui->setupUi(this);
    setWindowTitle("Калькулятор");
    setFixedSize(size());

    ui->lineEdit->setText("0");
    connectButtons();
}

calculator2::~calculator2() { delete ui; }

void calculator2::connectButtons() {
    // Цифры
    QList<QPushButton*> digitBtns = {
        ui->pushButton0, ui->pushButton1, ui->pushButton2,
        ui->pushButton3, ui->pushButton4, ui->pushButton5,
        ui->pushButton6, ui->pushButton7, ui->pushButton8,
        ui->pushButton9
    };
    for(QPushButton* btn : digitBtns)
        connect(btn, &QPushButton::clicked, this, &calculator2::on_digit_clicked);

    // Операции
    QList<QPushButton*> opBtns = {
        ui->pushButtonPlus, ui->pushButtonMinus,
        ui->pushButtonMultiply, ui->pushButtonDivide
    };
    for(QPushButton* btn : opBtns)
        connect(btn, &QPushButton::clicked, this, &calculator2::on_operation_clicked);
}

void calculator2::on_digit_clicked() {
    QPushButton* btn = qobject_cast<QPushButton*>(sender());
    QString val = btn->text();
    QString display = ui->lineEdit->text();

    if(userIsTypingSecondNumber) {
        ui->lineEdit->setText(val);
        userIsTypingSecondNumber = false;
    } else {
        if(display == "0") ui->lineEdit->setText(val);
        else if(display.length() < 10) ui->lineEdit->setText(display + val);
    }
}

void calculator2::on_operation_clicked()
{
    QPushButton* button = qobject_cast<QPushButton*>(sender());
    QString newOperation = button->text();

    // Если уже есть операция и пользователь вводил второе число
    if(!operation.isEmpty() && !userIsTypingSecondNumber) {
        // Вычисляем промежуточный результат
        secondNumber = ui->lineEdit->text().toDouble();
        double result = 0;

        if(operation == "+") {
            result = firstNumber + secondNumber;
        } else if(operation == "-") {
            result = firstNumber - secondNumber;
        } else if(operation == "*") {
            result = firstNumber * secondNumber;
        } else if(operation == "/") {
            if(secondNumber == 0) {
                QMessageBox::critical(this, "Ошибка", "Деление на ноль!");
                ui->lineEdit->setText("0");
                ui->lineEdit_2->setText("");
                operation = "";
                return;
            }
            result = firstNumber / secondNumber;
        }

        // Показываем промежуточный результат
        QString resStr = QString::number(result, 'g', 10);
        if(resStr.length() > 10) resStr = resStr.left(10);
        ui->lineEdit->setText(resStr);

        // Первое число для следующей операции - это результат
        firstNumber = result;
    } else {
        // Первая операция - просто запоминаем первое число
        firstNumber = ui->lineEdit->text().toDouble();
    }

    // Устанавливаем новую операцию
    operation = newOperation;

    // Показываем только знак операции во втором дисплее
    ui->lineEdit_2->setText(operation);

    userIsTypingSecondNumber = true;
}


void calculator2::on_pushButtonEqual_clicked() {
    secondNumber = ui->lineEdit->text().toDouble();
    double result = 0;

    if(operation == "+") result = firstNumber + secondNumber;
    else if(operation == "-") result = firstNumber - secondNumber;
    else if(operation == "*") result = firstNumber * secondNumber;
    else if(operation == "/") {
        if(secondNumber == 0) {
            QMessageBox::critical(this, "Ошибка", "Деление на ноль!");
            ui->lineEdit->setText("0");
            operation = "";
            return;
        }
        result = firstNumber / secondNumber;
    }

    QString resStr = QString::number(result, 'g', 10);
    if(resStr.length() > 10) resStr = resStr.left(10);
    ui->lineEdit->setText(resStr);
    operation = "";
    userIsTypingSecondNumber = true;
}

void calculator2::on_pushButtonClear_clicked() {
    ui->lineEdit->setText("0");
    firstNumber = 0; secondNumber = 0; operation = "";
    userIsTypingSecondNumber = false;
}

void calculator2::on_pushButtonDot_clicked() {
    if(!ui->lineEdit->text().contains("."))
        ui->lineEdit->setText(ui->lineEdit->text() + ".");
}

void calculator2::on_pushButtonPlusMinus_clicked() {
    double val = ui->lineEdit->text().toDouble();
    ui->lineEdit->setText(QString::number(-val, 'g', 10));
}

void calculator2::on_pushButtonPercent_clicked() {
    double val = ui->lineEdit->text().toDouble();
    ui->lineEdit->setText(QString::number(val / 100.0, 'g', 10));
}