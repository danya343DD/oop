#ifndef CALCULATOR2_H
#define CALCULATOR2_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class calculator2; }
QT_END_NAMESPACE

class calculator2 : public QMainWindow
{
    Q_OBJECT

public:
    calculator2(QWidget *parent = nullptr);
    ~calculator2();

private slots:
    void on_digit_clicked();
    void on_operation_clicked();
    void on_pushButtonEqual_clicked();
    void on_pushButtonClear_clicked();
    void on_pushButtonDot_clicked();
    void on_pushButtonPlusMinus_clicked();
    void on_pushButtonPercent_clicked();

private:
    Ui::calculator2 *ui;
    double firstNumber;
    double secondNumber;
    QString operation;
    bool userIsTypingSecondNumber;

    void connectButtons();
};

#endif // CALCULATOR2_H